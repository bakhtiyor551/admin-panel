import mysql from 'mysql2/promise';

export const pool = mysql.createPool({
    host: 'localhost', // или '127.0.0.1'
    user: 'root',
    password: '', // ваш пароль, если есть
    database: 'admin_panel',
    port: 3306 // если MySQL на стандартном порту
  });